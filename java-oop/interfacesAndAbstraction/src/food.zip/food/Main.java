package food;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        Map<String, Buyer> buyers = new HashMap<>();

        for (int i = 0; i < n; i++) {
            String[] tokens = scanner.nextLine().split("\\s+");

            Buyer buyer = tokens.length > 3 ?
                    new Citizen(tokens[0], Integer.parseInt(tokens[1]), tokens[2], tokens[3]) :
                    new Rebel(tokens[0], Integer.parseInt(tokens[1]), tokens[2]);

            buyers.put(tokens[0], buyer);
        }

        String input = scanner.nextLine();

        while (!input.equals("End")) {
            Buyer buyer = buyers.get(input);
            if (buyer != null) {
                buyer.buyFood();
            }
            input = scanner.nextLine();
        }

        int totalAmountFood = 0;
        for (Buyer value : buyers.values()) {
            totalAmountFood += value.getFood();
        }
        System.out.println(totalAmountFood);
    }
}
